<?php
require('DBconnect.php');
echo "<h1>Update Photo</h1>";

if (isset($_GET["pNo"])){     
    $pNo = $_GET["pNo"];

    $SQL = "SELECT * FROM photouser WHERE pNo = '$pNo'";


    if ($result = mysqli_query($link, $SQL)){
        echo "Please Choose New Image<br/><br/>";
    }

}else{
    echo "Please choose the correct photo!<br/>";
    echo "<h3><b><a href = 'photolist.php'> BACK TO ALBUM </a></b></h3>";
    exit();
}

?>

<form action = "updateGo.php" method = "POST" enctype = "multipart/form-data">
    <input type = "hidden" name = 'pNo' value = '<?php echo $pNo;?>'>
    <input type = "file" name = "newPhoto" accept = "image/*"></br>
    <input type = "submit">
</form>