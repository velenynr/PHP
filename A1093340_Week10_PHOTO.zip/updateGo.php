<?php
require("DBconnect.php");

if (isset($_POST["pNo"])){
    $pNo = $_POST["pNo"];
    $pathpart = pathinfo($_FILES['newPhoto']['name']);
    $extname = $pathpart['extension'];
    $now = time();
    // echo $extname."<br/>";

    $finalphoto = "Photo_".time().'.'.$extname;
    // echo $finalphoto."<br/>";
    // echo $now;
    $SQL = "UPDATE photouser SET pPath = '$finalphoto', pDate = $now WHERE pNo = $pNo";

    if (copy($_FILES['newPhoto']['tmp_name'], $finalphoto)){
        if (mysqli_query ($link, $SQL)){
            echo "<script type = 'text/javascript'>";
            echo "alert('Photo Updated Successfully')";
            echo "</script>";
            echo "<meta http-equiv='Refresh' content = '0; url=photolist.php'>";
        }else{
            echo "<script type = 'text/javascript'>";
            echo "alert('Update Photo Failed');";
            echo "</script>";
            echo "<meta http-equiv='Refresh' content = '0; url=updatePhoto.php'>";
        }
    }else{
        echo "<script type = 'text/javascript'>";
        echo "alert('Update Photo Failed');";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content='0; url=updatePhoto.php'>";
    }

}else{
    echo "<script type = 'text/javascript'>";
    echo "alert('Update Photo Failed');";
    echo "</script>";
    echo "<meta http-equiv='Refresh' content='0; url=updatePhoto.php'>";
}

?>