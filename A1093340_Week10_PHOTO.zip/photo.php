<html>
</body>
    <h1>Upload Photo<br/></h1>
    Welcome to <b>My Album</b>!<br/>Here, you may upload any photo, and we will save it to <u><b>your own photo album</b></u>!<br/><br/>

    <form action = "photoupload.php" method = "POST" enctype = "multipart/form-data">

    <input type = "file" name = "photo" accept = "image/*"></br>
    <input type = "submit">

    </form>
</body>
</html>