<?php
require ("DBconnect.php");

$SQL = "SELECT * FROM photouser";

echo "<h1>My Album</h1>";

if ($result=mysqli_query($link, $SQL)){
    echo "<table border = '1' width = 20%>";
    while ($row=mysqli_fetch_assoc($result)){
        echo "<tr>";
        echo "<td>";
        echo "<a href ='".$row['pPath']."'>";
        echo "<img src='".$row['pPath']."' width='30%'>";
        echo "</a>";
        echo "<br/><a href = 'updatePhoto.php?pNo=".$row["pNo"]."'>Update Photo</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
}


?>