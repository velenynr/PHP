<?php

require('DBConnect.php');

// $phototmpname = $_FILES["photo"]["tmp_name"];
// echo $phototmpname;

$pathpart = pathinfo($_FILES['photo']['name']);
$extname = $pathpart['extension'];
$now = time();
// echo $extname."<br/>";

$finalphoto = "Photo_".time().'.'.$extname;
// echo $finalphoto."<br/>";
echo $now;
$SQL = "INSERT INTO photouser (pPath, pDate) VALUES ('$finalphoto', $now)";


if (copy($_FILES['photo']['tmp_name'], $finalphoto)){
    if (mysqli_query ($link, $SQL)){
        echo "<script type = 'text/javascript'>";
        echo "alert('Photo Uploaded Successfully')";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content = '0; url=photolist.php'>";
    }else{
        echo "<script type = 'text/javascript'>";
        echo "alert('Upload Photo Failed');";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content = '0; url=photo.php'>";
    }
}else{
    echo "<script type = 'text/javascript'>";
        echo "alert('Upload Photo Failed');";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content='0; url=photo.php'>";
}

?>