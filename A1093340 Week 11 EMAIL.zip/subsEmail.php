<form action= "subsCheck.php" method="POST">

<h1>EZ Newspaper Subscription<br/></h1>
    Welcome to <b>EZ News</b>!<br/>We're happy to serve you with the newest and the most accurate news daily!<br/><br/>

Please input your email : <br/>
<input type = "email" name = "uEmail"><br/>
<input type = "submit" value = "SUBSCRIBE!">

</form>
