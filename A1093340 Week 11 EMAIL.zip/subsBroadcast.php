<form action= "subsGO.php" method="POST">

<h1>Newspaper Broadcast<br/></h1>
    Welcome to <b>EZ Newspaper Broadcast</b>!<br/>Here, you may broadcast today's news to everyone!<br/><br/>


<b>Please e all the followings: </b><br/>
Subject : <br/>
<input type = "text" name = "newsSbj" required><br/>
Content : <br/>
<textarea rows="10" cols="20" name="newsCont" required></textarea><br/><br/>
<input type = "submit" value = "SHARE">

</form>
