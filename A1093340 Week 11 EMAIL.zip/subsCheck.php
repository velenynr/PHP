<?php
    require('DBConnect.php');
    
    if (isset($_POST["uEmail"])){
        $uMail=$_POST["uEmail"];
        //echo $uNo;
        $SQL = "SELECT * FROM subsmail WHERE uEmail = '$uMail'";
       
        $found = mysqli_query($link, $SQL);

            if(mysqli_num_rows($found)==1){
                echo "<script type = 'text/javascript'>";
                echo "alert ('Subscribe Failed!')";
                echo "</script>";
                echo "<h1>Oops!</h1><br/>";
                echo "You may only subscribe once!^^<br/>";
            }else{
                echo "<script type = 'text/javascript'>";
                echo "alert ('Subscribe Success!')";
                echo "</script>";
                $SQL = "INSERT INTO subsmail (uEmail) VALUES ('$uMail')";
                if(mysqli_query($link, $SQL)){
                    echo "<h1>Yay!</h1><br/>";
                    echo "You've successfully subscribed to <b>EZ Newspaper</b>!^^<br/>";
                };
            }
                

    }else{
        echo "<h1>ERROR :(</h1>";
        echo "Please input your email first to subscribe!<br/>";
        echo "<h3><b><a href = 'subsEmail.php'> INPUT EMAIL </a></b></h3>";
    }


?>