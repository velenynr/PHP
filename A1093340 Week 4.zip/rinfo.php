<html>
<head>
    <link rel = "icon" href = /img/form.png type = "image/x-icon">
    <title> Registration Complete </title>

    <font face = "Verdana" size = 5px> Registration Data Preview<br/><br/></font>
</head>

<body>

    <font face = "Helvetica">

    <?php
    $firstName = $_POST["firstName"];
    $birth = $_POST["birth"];
    $gender = $_POST["gender"];
    $email = $_POST["email"];
    $tel = $_POST["tel"];
    $food = $_POST["food"];

    //$foods = implode(", ",$food); //gabisa save to database

    $foodsize = count($food);
    $size = $_POST["size"];
    $color = $_POST["color"];
    $comment = $_POST["comment"];
    $comment = strip_tags($comment);
    $comment = nl2br($comment);
    $upfile = $_FILES["upfile"];

    echo "<b>Name :</b> Mr./Mrs./Ms.".$firstName."<br/>";
    echo "<b>Birthday : </b>".$birth."<br/>";

    if ($gender == '1'){
        echo "<b>Sex : </b> Male <br/>";
    }else{
        echo "<b>Sex : </b> Female <br/>";
    }

    echo "<b>Email : </b>".$email."<br/>";
    echo "<b>Phone Number : </b>".$tel."<br/>";
    //echo "<b>你的飲食：</b>".$foods."<br/>";
    echo "<b>Food Preference : </b>";

    for($i = 0; $i < $foodsize; $i++){
        if ($i == 0){
            echo $food[$i];
        }else{
            echo ", ".$food[$i];
        }
    }

    echo "<br/>";
    echo "<b>T-Shirt Size : </b>".$size."<br/>";
    echo "<b>T-Shirt Color : </b>".$color."<br/>";
    echo "<b>Comment : </b>".$comment."<br/>";
    echo "<b>File Uploaded : </b>".$_FILES["upfile"]["name"]."<br/>";
    echo "<b>File Path : </b>".$_FILES["upfile"]["tmp_name"]."<br/>";
    echo "<b>File Size : </b>".$_FILES["upfile"]["size"]."<br/>";
    echo "<b>File Type : </b>".$_FILES["upfile"]["type"]."<br/>";

    if(copy($_FILES["upfile"]["tmp_name"], $_FILES["upfile"]["name"])){
        echo "File Uploaded successfully <br/>";
    }else{
        echo "Upload File failed<br/>";
    }

    ?>
    </font>

</body>
</html>