<html>
<head>

<link rel = "icon" href = "/img/blueshirt.png" type = "image/x-icon"/>
<title>T-Shirt Size Chart</title>

<!--<style>
    thead {color : 064b87;}
    tbody {color : 638eb3;}
    tfoot {color : violet;}

    table,TH,TD {
        border : 1px solid ;
    }
</style>-->

<style>
thead {
  background-color: #073a66;
  color: #b7eeec;
  text-align: center;
  font-weight: bold;
}

th, td {
  padding: 12px 15px;
}

tbody {
  border-bottom: 1px solid #dddddd;
}

tr:nth-of-type(even) {
  background-color: #f3f3f3;
}

  </style>

</head>

<body>

<?php

    echo "<body background = 'img/minimalistsea.jpg'>"

?>

<font face = "Times New Roman">
</br><center><h1><span style = "color : b7eeec; border : 3px solid #b7eeec; border-radius : 10px">&nbspFREE SIZE&nbsp</span></h1></center><br/><br/>
</font>

<center><img src = /img/size.jpg width = 25% border = 3px></center><br/><br/><br/><br/>

<font face = "Sans-serif">
<center>

<table border = 5 bgcolor = c5e4ff style = "width : 35%">
<thead><TR><TH>Inch</TH><TH>Shoulder</TH><TH>Chest</TH><TH>Length</TH><TH>Sleeve</TH></TR></font></thead>
<TR><TH>XS</TH><TD style = "text-align:center">38.5</TD><TD style = "text-align:center">45.5</TD><TD style = "text-align:center">63.5</TD><TD style = "text-align:center">19</TD></TR>
<TR><TH>S</TH><TD style = "text-align:center">44</TD><TD style = "text-align:center">48</TD><TD style = "text-align:center">64.5</TD><TD style = "text-align:center">20</TD></TR>
<TR><TH>M</TH><TD style = "text-align:center">44.5</TD><TD style = "text-align:center">50</TD><TD style = "text-align:center">68</TD><TD style = "text-align:center">22.5</TD></TR>
<TR><TH>L</TH><TD style = "text-align:center">46.5</TD><TD style = "text-align:center">52.5</TD><TD style = "text-align:center">71</TD><TD style = "text-align:center">23.5</TD></TR>
<TR><TH>XL</TH><TD style = "text-align:center">48.5</TD><TD style = "text-align:center">55</TD><TD style = "text-align:center">73</TD><TD style = "text-align:center">23.5</TD></TR>
<TR><TH>2L</TH><TD style = "text-align:center">55</TD><TD style = "text-align:center">61.5</TD><TD style = "text-align:center">76.5</TD><TD style = "text-align:center">24</TD></TR>

</center>
</table>
</font>
<br/><br/>

<h3><b><a href = KentingForm.php#form> BACK TO FORM </a></b><h3>

</body>

</html>