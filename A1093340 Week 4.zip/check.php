<html>

<head>
<link rel = "icon" href = /img/error.png type = "image/x-icon">

<style>
    body {
        margin : 0;
        padding : 0;
        font-family : Helvetica;
        background : linear-gradient(120deg, #a7c1ee, #fac2eb);
        height : 100vh;
        overflow : hidden;
    }

    .center {
        position : absolute;
        top : 50%;
        left : 50%;
        transform : translate(-50%,-50%);
        width : 400px;
        background : #fff;
        border-radius : 10px;
    }

    .center h1{
        text-align : center;
        padding : 0 0 20px 0;
        border-bottom : 1px solid silver;
    }

    .center h5{
        text-align : center;
        padding :0 0 20px 0;
        color : red;
    }

    @-webkit-keyframes spaceboots {
        0% { -webkit-transform: translate(2px, 1px) rotate(0deg); }
        10% { -webkit-transform: translate(-1px, -2px) rotate(-1deg); }
        20% { -webkit-transform: translate(-3px, 0px) rotate(1deg); }
        30% { -webkit-transform: translate(0px, 2px) rotate(0deg); }
        40% { -webkit-transform: translate(1px, -1px) rotate(1deg); }
        50% { -webkit-transform: translate(-1px, 2px) rotate(-1deg); }
        60% { -webkit-transform: translate(-3px, 1px) rotate(0deg); }
        70% { -webkit-transform: translate(2px, 1px) rotate(-1deg); }
        80% { -webkit-transform: translate(-1px, -1px) rotate(1deg); }
        90% { -webkit-transform: translate(2px, 2px) rotate(0deg); }
        100% { -webkit-transform: translate(1px, -2px) rotate(-1deg); }
    }

    .shake {
        -webkit-animation-name: spaceboots;
        -webkit-animation-duration: 0.8s;
        -webkit-transform-origin:50% 50%;
        -webkit-animation-iteration-count: 2s;
        -webkit-animation-timing-function: linear;
    }

    .center form {
        padding : 0 40px;
        box-sizing : border-box;
    }

    form .txt_field{
        position : relative;
        border-bottom : 2px solid #adadad;
        margin : 30px 0;
    }

    .txt_field input{
        width : 100%;
        padding : 0 5px;
        height : 40px;
        font-size : 16px;
        border : none;
        background : none;
        outline : none;
    }

    .txt_field label{
        position : absolute;
        top : 50%;
        left : 5px;
        color : #adadad;
        transform : translateY(-50%);
        font-size = 16px;
        pointer-events : none;
        transition : .5s;
    }

    .txt_field span::before{
        content : ' ';
        position : absolute;
        top : 40px;
        left : 0;
        width : 100%;
        height : 2px;
        background : red;
    }

    .txt_field input:focus ~ label, .txt_field input:valid ~ label{
        top : -5px;
        color : #2691d9;
    }

    .txt_field input:focus ~ span::before, .txt_field input:valid ~ span::before{
        width : 100%;
    }

    .pass{
        margin : -5px 0 20px 5px;
        color : #2691d9;
        cursor : pointer;
    }

    .pass:hover{
        text-decoration : underline;
    }

    input[type="submit"]{
        width : 100%;
        height : 50px;
        border : 1px solid;
        background : #2691d9;
        border-radius : 25px;
        font-size : 18px;
        color : #e9f4fb;
        font-weight : 700;
        cursor : pointer;
        outline : none;
    }

    input[type="submit"]:hover{
        border-color : #2691d9;
        transition : 0.5s;
    }

    .signup_page{
        margin : 30px 0;
        text-align : center;
        font-size : 16px;
        color : Red;
    }

    .signup_page a{
        color : #2691d9;
        text-decoration : none;
    }
    
    .signup_page a:hover{
        text-decoration : underline;
    }
</style>

<title> Login Failed</title>

</head>

<body>

<?php

$yourUser = $_POST["yourUser"];
$yourPass = $_POST["yourPass"];

##echo "Username : ".$yourUser."<br/>";
##echo "Password : ".$yourPass."<br/>";

if ($yourUser == "Velen773" && $yourPass == "355"){
    header("Location: KentingForm.php");
    exit();
}else{
    ##echo "<script>alert('Wrong Username or Password!');</script>";
}

?>

<div class = "center">
<h1> Login </h1>

<h5 class = "shake"> <u>Wrong Username or Password!</u> </h5>

<form action = "check.php" method = "POST">
    <div class = "txt_field">
        <input type = "text" name = yourUser required>
        <label> Username </label>    
        <span></span>
    </div>

    <div class = "txt_field">
        <input type = "password" name = yourPass required>
        <label> Password </label>
        <span></span>
    </div>

    <div class = "pass"> Forgot Password? </div>
        
    <input type = "submit" value = "Login">

    <div class = "signup_page">
        <div class = "shake">Don't have an account? 
        <a href = "/signup.php">Sign up</a></h5></div>
        
</form>



</body>
</html>
