<?php
session_start();
if (isset($_SESSION['visitedLogin'])){
    if (isset($_SESSION['loginFromUser'])){
        if ($_SESSION['loginFromUser'] == "Yes"){
            echo "<h3><b><a href = 'logout.php'> LOGOUT </a></b></h3>";
        }else{
            echo "Please Login First!<br/>";
            echo "<h3><b><a href = 'login.php'> LOGIN </a></b></h3>";
            exit();
        }
    }else{
        echo "Please Login First!<br/>";
        echo "<h3><b><a href = 'login.php'> LOGIN </a></b></h3>";
        exit();    
    }
}else{
    echo "Please Login First!<br/>";
    echo "<h3><b><a href = 'login.php'> LOGIN </a></b></h3>";
    exit();
}

?>

<html>

<head>

<style>
.myDiv{
    width : 92%;
    border : 100px;
    background-color : #95D9D2;
    opacity: 0.7;
    padding : 30px 25px;
    border-radius : 10px;
}

th {
    text-align : left;
    height : 50px;
    width : 40%;
}

td {
    text-align : left;
    width : 80%;
    height : 50px;
}

input, textarea, select, button{
    border-top-style : hidden;
    border-right-style : hidden;
    border-left-style : hidden;
    border-bottom-style : hidden;
    background-color : #EDFCFF;
    border-radius : 5px;
}

.option{
  background: #fff;
  height: 40%;
  width: 40%;
  display: flex;
  flex-wrap : wrap;
  align-items: center;
  justify-content: space-between;
  margin: 10px 10px;
  border-radius: 10px;
  cursor: pointer;
  padding: 0 10px;
  border: 2px solid lightgrey;
  transition: all 0.3s ease;
}

input[type="radio"]{
  display: none;
}

#option-1:checked:checked ~ .option-1,
#option-2:checked:checked ~ .option-2{
    border-radius : 10px;
    background: #498EA8;
}

span{
  font-size: 20px;
  color: black;
}

#option-1:checked:checked ~ .option-1 span,
#option-2:checked:checked ~ .option-2 span{
  color: #fff;
}


</style>

<meta name="keywords" content="墾丁旅遊, 墾丁, Visit Kenting, Kenting">
<link rel = "icon" href = "/img/beachIcon.webp" type = "image/x-icon"/>

<title>墾丁三日遊 Registration Form</title>

<font color = "#77DFD3" size = "5"><center><h1>墾丁三日遊</h1></center></font>

</head>

<body>

    <?php
        echo "<body background = '/img/minimalistsea.jpg'>";
    ?>

    <ol>
    <font face = "Helvetica" size = 5 color = "#ffb948"><u><h4><li>Itenerary</h4></u></font>

    <p><font size = 4 color = "#FFE5B4" face = "Verdana">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href = "https://en.wikipedia.org/wiki/Kenting_National_Park" target = "new"><b>Kenting</b></a> 
    is a wonderful place that located at the most southern part of Taiwan. It's famous for its beach, such as <i>Kenting Beach, White Sand Bay</i>, etc. 
    But, besides of that, there are so much more amazing places worth to visit in Kenting, like <i>Eluanbi Park, Fengchuisha, Longpan Park</i> and so many more! 
    And, happy to tell you guys that we will hold a 3-days trip to Kenting!!!</font></p><br/>

    <div class = "myDiv">
        <font size = 3 color = "#000000" face = "Verdana">Here is the itenerary of our 3 days trip:<br/><br/>
    
    <ol>
        <li><b>1st Day : <font color = "080AA1"><i>Hello Marine!</i></font></b><br/>
        07:00 Gathering<br/>
        07:45 Set off<br/>
        09:30 Little Bali Rock<br/>
        12:00 Lunch<br/>
        13:00 Maobitou Park<br/>
        14:00 Gathering<br/>
        15:30 White Sand Bay<br/>
        17:00 Kentington Resort<br/>
        18:00 Dinner<br/>
        19:00 Mini game<br/>
        20:00 End of First Day<br/><br/>
        
        <li><b>2nd Day : <font color = "080AA1"><i>Southern Taiwan</i></font></b><br/>
        08:00 Get up<br/>
        09:00 Breakfast<br/>
        09:30 Gathering<br/>
        09:45 Set off<br/>
        10:15 Longpan Park<br/>
        11:00 Fengchuisha<br/>
        12:30 Lunch<br/>
        14:00 Southern Most Point of Taiwan<br/>
        15:00 Eluanbi Lighthouse<br/>
        17:00 Chuan Fan Rock<br/>
        18:00 Dinner<br/>
        19:00 Kenting Night Market<br/>
        20:00 End of Second Day<br/><br/>
        
        <li><b>3nd Day : <font color = "080AA1"><i>How Dare Are You?</i></font></b><br/>
        08:00 Get up<br/>
        09:00 Breakfast<br/>
        09:30 Gathering<br/>
        09:45 Mini game<br/>
        12:00 Lunch<br/>
        13:00 National Museum of Marine Biology and Aquarium<br/>
        16:50 Gathering<br/>
        17:00 Back to school<br/>
        18:30 Arrived<br/>
    </ol>

        </font>
    </div>

    <font face = "Helvetica" size = 5 color = "#ffb948"><u><h4><li>Registration Form</h4></u></font>

    <div class = "myDiv">
        <center>
        <table style = "font-size : 18; font-family : Helvetica">
        <form action = "rinfo.php" method = "POST" enctype = "multipart/form-data">
    
            <TR>
                <TH><u>Name:</u></TH>
                <TD><input type = "text" style = "width : 100%; height : 70%" name = firstName placeholder = "First Name" required></TD>
            </TR>
            
            <TR>
                <TH><u>Birthday:</u></TH>
                <TD><input type = "date" style = "width : 100%;  height : 70%" name = birth required></TD>
            </TR>
            
            <div class = "wrapper">
            <TR>
                <TH><u>Gender:</u></TH>
                <TD><input type = "radio" name = gender value = "1" id = "option-1" checked>
                <input type = "radio" name = gender value = "2" id = "option-2"> 
                <label for = "option-1" class = "option option-1">
                    <span>Male</span>
                </label>

                <label for = "option-2" class = "option option-2">
                    <span>Female</span>
                </label>
                </TD>
            </TR>
            </div>
            
            <TR>
                <TH><u>Email:</u></TH>
                <TD><input type = "email" style = "width : 100%;  height : 70%" name = email placeholder = "Email Address" required></TD>
            </TR>

            <TR>
                <TH><u>Phone Number:</u></TH>
                <TD><input type="tel" style = "width : 100%; height : 70%" pattern="[0-9]{10}" placeholder="Phone Number" name = tel required style = "width : 100"></TD>
            </TR>

            <TR>
                <TH><u>Food Preference:</u></TH>
                <TD><input type="checkbox" name = food[] value = Vegetarian>Vegetarian&nbsp&nbsp<input type="checkbox" name = food[] value = Pork>Pork&nbsp&nbsp<input type="checkbox" name = food[] value = Beef>Beef&nbsp&nbsp<input type="checkbox" name = food[] value = Seafood>Seafood&nbsp&nbsp</TD>
            </TR>
            
            <TR>
                <TH><u>T-shirt Size :</u><br/>
                <a href = "tshirt.php" style = "font-size : 15" target = "new">Size Chart</a></TH>
                <TD>    
                <select name = size style = "width : 100%; height : 70%" required>
                    <option value = XS>XS</option>
                    <option value = S>S</option>
                    <option value = S>M</option>
                    <option value = S>L</option>
                    <option value = S>XL</option>
                </select></TD>
            </TR>
            
            <TR>
                <TH><u>T-Shirt Color:</u></TH>
                <TD>
                <select name = color style = "width : 100%; height : 70%"required>
                    <option value = White>White</option>
                    <option value = Navy>Navy</option>
                    <option value = Khaki>Khaki</option>
                    <option value = Black>Black</option>
                    <option value = Marron>Maroon</option>
                </select></TD>
            </TR>

            <TR>
                <TH><u>Ticket(s) for:</u></TH>
                <TD><input type = "number" style = "width : 100%; height : 70%" min = "1" max = "20" name = ticket required></TD>
            </TR>

            <TR>
                <TH><u>Comment：</u></TH>
                <TD><textarea name = comment cols = 40px rows = 10px placeholder = "Your Comment"></textarea></TD>
            </TR>

            <TR>
                <TH><u>File Upload :</u></TH>
                <TD><input type = "file" name = "upfile"></TD>
            </TR><br/>
            
            <TR>
                <TH><br/></TH>
            </TR>
            
            <TR>
                <TH colspan = "2"><center><input type = "submit" name = "submit" value = "SEND!" style = "font-face: 'Impact'; font-size : 20px; color : teal; height: 30px; width: 25%; background-color: ##58436b; border: 3pt ridge lightgrey"></center></TH>
            </TR>
            
            </font>
        
        </form>
        </table>
        </center>
    </div>
    </ol>

</body>

</html>