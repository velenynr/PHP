<?php 
session_start();
?>

<html>
<head>

<link rel = "icon" href = /img/error.png type = "image/x-icon">

<title>Password Not Matches</title>

<style>

    body {
        display : flex;
        justify-content : center;
        align-items : center;
        margin : 0;
        padding : 0;
        font-family : Helvetica;
        background : linear-gradient(120deg, #a7c1ee, #fac2eb);
        height : 100vh;
    }

    .center {
        max-width : 550px;
        width : 100%;
        background : #fff;
        border-radius : 10px;
    }

    .center h1{
        text-align : center;
        padding : 0 0 20px 0;
        border-bottom : 1px solid silver;
    }

    .center h5{
        text-align : center;
        padding :0 0 20px 0;
        color : red;
    }

    @-webkit-keyframes spaceboots {
        0% { -webkit-transform: translate(2px, 1px) rotate(0deg); }
        10% { -webkit-transform: translate(-1px, -2px) rotate(-1deg); }
        20% { -webkit-transform: translate(-3px, 0px) rotate(1deg); }
        30% { -webkit-transform: translate(0px, 2px) rotate(0deg); }
        40% { -webkit-transform: translate(1px, -1px) rotate(1deg); }
        50% { -webkit-transform: translate(-1px, 2px) rotate(-1deg); }
        60% { -webkit-transform: translate(-3px, 1px) rotate(0deg); }
        70% { -webkit-transform: translate(2px, 1px) rotate(-1deg); }
        80% { -webkit-transform: translate(-1px, -1px) rotate(1deg); }
        90% { -webkit-transform: translate(2px, 2px) rotate(0deg); }
        100% { -webkit-transform: translate(1px, -2px) rotate(-1deg); }
    }

    .shake {
        -webkit-animation-name: spaceboots;
        -webkit-animation-duration: 0.8s;
        -webkit-transform-origin:50% 50%;
        -webkit-animation-iteration-count: 2s;
        -webkit-animation-timing-function: linear;
    }

    .center form {
        padding : 0 40px;
        box-sizing : border-box;
    }

    form .usr-data{
        display : flex;
        flex-wrap : wrap;
        justify-content : space-between;
    }

    form .txt_field{
        position : relative;
        border-bottom : 2px solid #adadad;
        margin : 30px 0;
    }

    .txt_field input{
        width : calc(100%/2-20px);
        padding : 0 10%;
        height : 40px;
        font-size : 16px;
        border : none;
        background : none;
        outline : none;
    }

    .txt_field label{
        position : absolute;
        top : 50%;
        left : 5px;
        color : #adadad;
        transform : translateY(-50%);
        font-size = 16px;
        pointer-events : none;
        transition : .5s;
    }

    .txt_field span::before{
        content : ' ';
        position : absolute;
        top : 40px;
        left : 0;
        width : 100%;
        height : 2px;
        background : #2691d9;
    }

    .txt_field input:focus ~ label, .txt_field input:valid ~ label{
        top : -5px;
        color : #2691d9;
    }

    .txt_field input:focus ~ span::before, .txt_field input:valid ~ span::before{
        width : 100%;
    }

    input[type="submit"]{
        width : 100%;
        height : 50px;
        border : 1px solid;
        background : #2691d9;
        border-radius : 25px;
        font-size : 18px;
        color : #e9f4fb;
        font-weight : 700;
        cursor : pointer;
        outline : none;
    }

    input[type="submit"]:hover{
        border-color : #2691d9;
        transition : 0.5s;
    }

    .login_page{
        margin : 30px 0;
        text-align : center;
        font-size : 16px;
        color : #666666;
    }

    .login_page a{
        color : #2691d9;
        text-decoration : none;
    }
    
    .login_page a:hover{
        text-decoration : underline;
    }

</style>

</head>

<body>

<?php


if (isset($_POST["newName"])){
    if($_POST["newName"]!=null){
        $newName = $_POST["newName"];
        $newUser = $_POST["newUser"];
        $newEmail = $_POST["newEmail"];
        $newTel = $_POST["newTel"];
        $newPass = $_POST["newPass"];
        $reNewPass = $_POST["reNewPass"];
    
        if ($reNewPass == $newPass){
            $_SESSION['loginFromUser'] = "Yes";
            header("Location: KentingForm.php");
            exit();
        }else{
            ##echo "<script>alert('Wrong Username or Password!');</script>";
        }

    }else {
        header("Location: signup.php");
    }
}else{
    header("Location: signup.php");
}

?>

<div class = "center">
<h1> Registration </h1>

<h5 class = "shake"> <u> Password Unmatch!</u> </h5>

<form action = "regisCheck.php" method = "POST">
    <div class = "usr-data">

        <div class = "txt_field">
            <input type = "text" name = "newName" required>
            <label> Full Name </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "text" name = "newUser" required>
            <label> Username </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "email" name = "newEmail" required>
            <label> Email Address </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "tel" name = "newTel" required>
            <label> Phone Number </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "password" name = "newPass" required>
            <label> Password </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "password" name = "reNewPass"required>
            <label> Confirm Password </label>    
            <span></span>
        </div>

    </div>
    
    <input type = "submit" value = "Register">

    <div class = "login_page">
        Already have an account? 
        <a href = "index.php">Log in</a>


</form>

</div>
</body>


</html>