<?php
session_start();
?>

<html>
<head>

<link rel = "icon" href = /img/login.png type = "image/x-icon">

<title>Sign Up</title>

<style>

    body {
        display : flex;
        justify-content : center;
        align-items : center;
        margin : 0;
        padding : 0;
        font-family : Helvetica;
        background : linear-gradient(120deg, #a7c1ee, #fac2eb);
        height : 100vh;
    }

    .center {
        max-width : 550px;
        width : 100%;
        background : #fff;
        border-radius : 10px;
    }

    .center h1{
        text-align : center;
        padding : 0 0 20px 0;
        border-bottom : 1px solid silver;
    }

    .center form {
        padding : 0 40px;
        box-sizing : border-box;
    }

    form .usr-data{
        display : flex;
        flex-wrap : wrap;
        justify-content : space-between;
    }

    form .txt_field{
        position : relative;
        border-bottom : 2px solid #adadad;
        margin : 30px 0;
    }

    .txt_field input{
        width : calc(100%/2-20px);
        padding : 0 10%;
        height : 40px;
        font-size : 16px;
        border : none;
        background : none;
        outline : none;
    }

    .txt_field label{
        position : absolute;
        top : 50%;
        left : 5px;
        color : #adadad;
        transform : translateY(-50%);
        font-size = 16px;
        pointer-events : none;
        transition : .5s;
    }

    .txt_field span::before{
        content : ' ';
        position : absolute;
        top : 40px;
        left : 0;
        width : 100%;
        height : 2px;
        background : #2691d9;
    }

    .txt_field input:focus ~ label, .txt_field input:valid ~ label{
        top : -5px;
        color : #2691d9;
    }

    .txt_field input:focus ~ span::before, .txt_field input:valid ~ span::before{
        width : 100%;
    }

    input[type="submit"]{
        width : 100%;
        height : 50px;
        border : 1px solid;
        background : #2691d9;
        border-radius : 25px;
        font-size : 18px;
        color : #e9f4fb;
        font-weight : 700;
        cursor : pointer;
        outline : none;
    }

    input[type="submit"]:hover{
        border-color : #2691d9;
        transition : 0.5s;
    }

    .login_page{
        margin : 30px 0;
        text-align : center;
        font-size : 16px;
        color : #666666;
    }

    .login_page a{
        color : #2691d9;
        text-decoration : none;
    }
    
    .login_page a:hover{
        text-decoration : underline;
    }

</style>

</head>

<body>

<div class = "center">
<h1> Registration </h1>

<form action = "regisCheck.php" method = "POST">
    <div class = "usr-data">

        <div class = "txt_field">
            <input type = "text" name = "newName" required>
            <label> Full Name </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "text" name = "newUser" required>
            <label> Username </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "email" name = "newEmail" required>
            <label> Email Address </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "tel" name = "newTel" required>
            <label> Phone Number </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "password" name = "newPass" required>
            <label> Password </label>    
            <span></span>
        </div>

        <div class = "txt_field">
            <input type = "password" name = "reNewPass"required>
            <label> Confirm Password </label>    
            <span></span>
        </div>

    </div>
    
    <input type = "submit" value = "Register">

    <div class = "login_page">
        Already have an account? 
        <a href = "login.php">Log in</a>


</form>

</div>

<?php

    $_SESSION["visitedRegist"]="Yes";
    
?>

</body>


</html>